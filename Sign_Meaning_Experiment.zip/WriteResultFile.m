function [] = WriteResultFile(infoVector)

%A simpler function that writes out whatever you give it, with commas
%between!  It makes sure everything is a char before sending it along.

global parameters


stringVector = {};

for v=1:length(infoVector)
    if isnumeric(infoVector{v})
        stringVector{v} = num2str(infoVector{v});
    else
        stringVector{v} = char(infoVector{v});
    end
end
        
stringOut = strjoin(stringVector, ',');
stringOut = strcat(stringOut, '\n');

% Write trial result to the file!
fprintf(parameters.datafilepointer, stringOut);


end